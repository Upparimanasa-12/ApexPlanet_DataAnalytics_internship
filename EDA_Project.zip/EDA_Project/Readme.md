Project Objective

The objective of this project is to perform Exploratory Data Analysis (EDA) on a customer transaction dataset to uncover patterns, trends, and relationships.
The project also focuses on using SQL for business analysis and designing a static dashboard mock-up to present key performance indicators (KPIs).

Tools Used

Python (Pandas, Matplotlib, Seaborn)

SQL (SQLite) for business queries

Google Colab for analysis and SQL execution

MS Excel / PowerPoint / Google Slides for dashboard mock-up

GitHub for project version control

Key Insights

Certain product categories contribute more to overall revenue

Payment mode preferences vary across customers

City-wise analysis shows differences in revenue contribution

A few customers make multiple transactions, indicating repeat behavior

Transaction amounts vary significantly across dates and categories
